package org.example;
import org.junit.Assert;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.Test;

//import static org.junit.jupiter.api.Assertions.*;

public class QuicksortTest {


    //@org.junit.jupiter.api.Test
    @org.junit.Test
    public void quickSortTest() {
        int[] a = new int[] {5, 4, 3, 2, 1};
        int[] res = new int[] {1 , 2, 3, 4, 5};
        Quicksort Qsort = new Quicksort();
        Assert.assertArrayEquals(res, Qsort.QuickSort(a,0, a.length-1));
    }

    //@org.junit.jupiter.api.Test
    @org.junit.Test
    public void quickSortTest1() {
        int[] a = new int[] {1, 2, 3, 4, 5};
        int[] res = new int[] {1 , 2, 3, 4, 5};
        Quicksort Qsort = new Quicksort();
        Assert.assertArrayEquals(res, Qsort.QuickSort(a,0, a.length-1));
    }

    //@org.junit.jupiter.api.Test
    @org.junit.Test
    public void quickSortTest2() {
        int[] a = new int[] {2, 4, 1, 6, 8};
        int[] res = new int[] {1 , 2, 4, 6, 8};
        Quicksort Qsort = new Quicksort();
        Assert.assertArrayEquals(res, Qsort.QuickSort(a,0, a.length-1));
    }

    @org.junit.Test
    public void quickSortTest3() {
        int[] a = new int[] {1, 1, 1, 1, 1};
        int[] res = new int[] {1 , 1, 1, 1, 1};
        Quicksort Qsort = new Quicksort();
        Assert.assertArrayEquals(res, Qsort.QuickSort(a,0, a.length-1));
    }


}