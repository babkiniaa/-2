package org.example;
import org.junit.Assert;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.Test;

//import static org.junit.jupiter.api.Assertions.*;

public class BubleSortTest {

    @org.junit.Test
    public void bubleSortTest() {
        int[] a = new int[] {5, 4, 3, 2, 1};
        int[] res = new int[] {1 , 2, 3, 4, 5};
        BubleSort Bsort = new BubleSort();
        Assert.assertArrayEquals(res, Bsort.BubleSort(a));
    }

    //@org.junit.jupiter.api.Test
    @org.junit.Test
    //@Test
    public void bubleSortTest1() {
        int[] a = new int[] {1, 2, 3, 4, 5};
        int[] res = new int[] {1 , 2, 3, 4, 5};
        BubleSort Bsort = new BubleSort();
        Assert.assertArrayEquals(res, Bsort.BubleSort(a));
    }

    //@org.junit.jupiter.api.Test
    @org.junit.Test
    public void bubleSortTest2() {
        int[] a = new int[] {1, 2, 1, 2, 1};
        int[] res = new int[] {1, 1, 1, 2, 2};
        BubleSort Bsort = new BubleSort();
        Assert.assertArrayEquals(res, Bsort.BubleSort(a));
    }

    @org.junit.Test
    public void bubleSortTest3() {
        int[] a = new int[] {1, 1, 1, 1, 1};
        int[] res = new int[] {1, 1, 1, 1, 1};
        BubleSort Bsort = new BubleSort();
        Assert.assertArrayEquals(res, Bsort.BubleSort(a));
    }

}