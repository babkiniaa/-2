package org.example;

public class Main {
    public static void main(String[] args) {
        int[] a = new int[] {2, 4, 5, 2, 7, 8};
        BubleSort Bsort = new BubleSort();
        int[] res = Bsort.BubleSort(a);
        for (int i=0; i<a.length; i++){
            System.out.println(res[i]);
        }
        Quicksort Qsort = new Quicksort();
        int[] res1 = Qsort.QuickSort(a,0, a.length-1);
        for (int i=0; i<a.length; i++){
            System.out.println(res1[i]);
        }

        //System.out.println("Hello world!");
    }
}